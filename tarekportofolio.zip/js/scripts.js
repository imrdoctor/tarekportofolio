function showOverlay(element) {
    var src = element.getAttribute("src");
    document.getElementById("overlayImg").src = src;
    document.getElementById("overlay").style.display = "flex"; // تغييرها إلى flex بدلاً من block
}

function closeOverlay() {
    document.getElementById("overlay").style.display = "none";
}

//    

// Scrolling before show & hide
window.onload = function() {
    var homeLink = document.querySelector('.nav-item:nth-child(1) .nav-link'); 
    var allLinks = document.querySelectorAll('.nav-item .nav-link'); 

    function updateActiveLink() {
        var scrollY = window.scrollY;

        allLinks.forEach(function(link) {
            link.classList.remove("active");
        });

        if (scrollY < 130) {
            homeLink.classList.add("active");
        } else if (scrollY >= 130 && scrollY < 530) {
            allLinks[1].classList.add("active");
        } else if (scrollY >= 530 && scrollY < 7050) {
            allLinks[2].classList.add("active");
        } else if (scrollY >= 7050 && scrollY < 7730) {
            allLinks[3].classList.add("active");
        } else if (scrollY >= 7730) {
            allLinks[4].classList.add("active");
        }
    }

    window.onscroll = function() {
        updateActiveLink();
    };

    updateActiveLink();
};



  
// // // // // // // // // // // // // 
// function printCurrentWindowScroll() {
//     console.log(window.scrollY);
// }

// window.addEventListener('scroll', function() {
//     printCurrentWindowScroll();
// });

// printCurrentWindowScroll();